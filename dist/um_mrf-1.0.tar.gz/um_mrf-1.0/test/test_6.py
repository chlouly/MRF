# import numpy as np
# from test_globals import *

# from UM_MRF import MRFSim, Params, GRE
# import UM_MRF
# print(UM_MRF.__file__)

from pathlib import Path
import sys
import matplotlib.pyplot as plt

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
from test_globals import *
from src.UM_MRF import *

SCHED_PATH = "/home/clouly/DEV/sched_bldr"
DICT_PATH = "/home/clouly/DEV/dicts"


if __name__ == "__main__":
    # T1 and T2 fitting (generating dictionary)
    T1_f = np.linspace(400, 800, 40)
    T2_f = np.linspace(1, 50, 50)
    #T2_f = 20
    flip = np.linspace(10, 50, 30)
    #flip = 50 * 0.67

    dyn_time = False

    PW = 2.5            # RO RF Pulse Width [ms]
    ETL = 20            # RO Echo Train Length
    ESP = 40            # RO Echo Spacing [ms]
    delay = 8           # RO Delay before echos play [ms]
    crush_off = 3.5     # RO Crusher offset (time between the end of an RF pulse and a crusher) [ms]
    samp_off = 2        # RO Sample offset (time between the end of an RF pulse and a sample) [ms]

    sample_times = (np.arange(ETL) * ESP) + delay + PW + 2
    #crush_times = (np.arange(ETL) * ESP) + delay - crush_off
    crush_times = np.array([])

    p = Params(T1_f, T2_f, T1_s, 0.0000, 0.0000, 0, lam, 0, 0, 0, BAT, 1, 1, flip)
    #p.resume(DICT_PATH + "/90007_GRE_BALL.h5")
    ps = MRFSim(p)

    ro_block = GRE(2.5, 20, 8, 40, 1, dynamic_time=dyn_time, crusher_times=crush_times, sample_times=sample_times, avg_samples=True)

    ps.read_sched(SCHED_PATH + "/90008", ro_block, dyn_time=dyn_time)

    ps.setup()

    ps.generate_dict(DICT_PATH + "/90008_virt_test.h5")

    ps.run_all_np()

    






    # #1
    # p_1 = Params(T1_f[50], T2_f[10], T1_s, 0.0000, 0.0000, 0, lam, 0, 0, 0, BAT, 1, 1, flip[10])
    # #p.resume(DICT_PATH + "/90007_GRE_BALL.h5")
    # ps_1 = MRFSim(p_1)

    # ro_block = GRE(2.5, 20, 8, 40, 0.1, dynamic_time=dyn_time, crusher_times=crush_times, sample_times=sample_times, avg_samples=True)

    # ps_1.read_sched(SCHED_PATH + "/90008", ro_block, dyn_time=dyn_time)

    # ps_1.setup()

    # # ps.generate_dict(DICT_PATH + "/90008_FLOW_corr_crush.h5")

    # ps_1.run_all_np()


    # #2
    # p_2 = Params(T1_f[50], T2_f[10], T1_s, 0.0000, 0.0000, 0, lam, 0, 0, 0, BAT, 1, 1, flip[29])
    # #p.resume(DICT_PATH + "/90007_GRE_BALL.h5")
    # ps_2 = MRFSim(p_2)

    # ro_block = GRE(2.5, 20, 8, 40, 0.1, dynamic_time=dyn_time, crusher_times=crush_times, sample_times=sample_times, avg_samples=True)

    # ps_2.read_sched(SCHED_PATH + "/90008", ro_block, dyn_time=dyn_time)

    # ps_2.setup()

    # # ps.generate_dict(DICT_PATH + "/90008_FLOW_corr_crush.h5")

    # ps_2.run_all_np()

    # print(T1_f[50], T2_f[10], flip[3])



    # samps_1 = ps_1.samples
    # samps_2 = ps_2.samples

    # plt.plot(np.abs(samps_1), label=f"flip={flip[10]}")
    # plt.plot(np.abs(samps_2), label=f"flip={flip[29]}")
    # plt.legend()
    # plt.show()
    